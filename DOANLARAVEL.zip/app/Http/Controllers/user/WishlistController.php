<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Logo;
use App\Models\Wishlist;
use Auth;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;

class WishlistController extends Controller {

  public function index() {
      $logos=Logo::all();
      $categorys = Category::all();
//    $contacts=Contact::all();
//    return view('user.page.contact',compact('contacts'));
    $wishlists = Wishlist::where('customer_id',Auth::guard('account_customer')->id())->latest()->get();
    return view('user.page.wishlish',compact('wishlists','logos','categorys'));
  }
  public function addToWishlist($product_id) {
    $status=Wishlist::where('customer_id',Auth::guard('account_customer')->id())->where('product_id',$product_id)->first();
    if(isset($status->customer_id) and isset($status->product_id)) {
      return redirect()->back()->with('cart', 'Sản phẩm đã tồn tại trong danh sách yêu thích');
    }else{
      if (Auth::guard('account_customer')->check()) {
        Wishlist::insert([
          'customer_id' => Auth::guard('account_customer')->id(),
          'product_id' => $product_id,
        ]);
        return Redirect()
          ->back()
          ->with('cart', 'Sản phẩm đã thêm vào yêu thích');
      }
      else {
        return Redirect()
          ->route('shopping.login')
          ->with('cart', 'Hãy đăng nhập');
      }
    }
  }
  public function destroy($wishlist_id){
    Wishlist::where('id',$wishlist_id)->where('customer_id',Auth::guard('account_customer')->id())->delete();
    return Redirect()->back()->with('wishlist','Sản phẩm yêu thích đã xóa');
  }

}
