$("#velonic-slider,#velonic-slider-2").owlCarousel({loop:!0,margin:10,slideSpeed:300,paginationSpeed:400,singleItem:!0,autoPlay:!0,responsive:{0:{items:1}}});
